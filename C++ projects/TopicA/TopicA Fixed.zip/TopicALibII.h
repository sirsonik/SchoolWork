/* Donald Eckels
Topic A Project
1/27/2012

TopicALibII.h*/

#ifndef TOPICALIBII_H
#define TOPICALIBII_H

using namespace std;

void Input (double *, double **);	//function prototypes that are in TopicALibII.cpp
bool Check (string &num);
double Divide (double *,double **);
void Display (double *, double **, double ***);

#endif